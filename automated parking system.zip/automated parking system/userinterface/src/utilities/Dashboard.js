import React from 'react'

const Dashboard = ({title}) => {
  return (
    <div className='dashboard'>
        <h2>{title}</h2>
    </div>
  )
}

export default Dashboard